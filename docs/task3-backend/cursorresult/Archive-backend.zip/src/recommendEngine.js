import { fishingSpots } from "./spots.js";

const spotsById = new Map(fishingSpots.map((s) => [s.id, s]));

const FISH_LABELS = {
  snapper: "Snapper",
  kahawai: "Kahawai",
  trevally: "Trevally",
  trout: "Trout",
  perch: "Perch",
};

const WATER_LABELS = {
  harbor: "harbor",
  coastal: "coastal water",
  lake: "still lake water",
  rockyCoast: "rocky coast",
  river: "moving river water",
};

function labelWaterType(waterType) {
  return WATER_LABELS[waterType] ?? waterType;
}

function formatTargetFish(targetFish) {
  if (!targetFish) return "No preference";
  return FISH_LABELS[targetFish] ?? targetFish;
}

function resolveFishKey(spot, targetFish) {
  if (targetFish && spot.commonFish.includes(targetFish)) {
    return targetFish;
  }
  return spot.commonFish[0];
}

function pickBait(fishKey, weather) {
  const dull = weather === "rainy" || weather === "overcast";
  const baits = {
    snapper: dull
      ? "Shellfish or tough squid strips"
      : "Pilchard strips or squid",
    kahawai: "Small strip bait or a simple silver jig (steady retrieve)",
    trevally: "Small strip bait fished near structure",
    trout: dull
      ? "Worm or egg imitation under a float"
      : "Small spinner or worm",
    perch: "Worm or maggot under a float",
  };
  return baits[fishKey] ?? "General-purpose bait for local conditions";
}

function pickLineDepth(waterType, windLevel, timeOfDay) {
  if (windLevel === "high") {
    if (waterType === "lake" || waterType === "river") {
      return "Mid-depth (below rough surface water)";
    }
    return "Near bottom";
  }
  if (waterType === "rockyCoast") {
    return windLevel === "low" ? "Mid-depth along edges" : "Near bottom in lanes";
  }
  if (waterType === "harbor" || waterType === "coastal") {
    if (timeOfDay === "night" || timeOfDay === "evening") {
      return "Near bottom";
    }
    return "Mid-depth";
  }
  if (windLevel === "low") {
    return "Shallow to mid-depth";
  }
  return "Mid-depth";
}

function pickSinkerWeight(windLevel, waterType) {
  const base = { low: "light", medium: "medium", high: "heavy" }[windLevel];
  if (waterType === "rockyCoast" && windLevel !== "low") {
    return "heavy (hold in surge)";
  }
  return base;
}

function pickFloatType(waterType, windLevel, lineDepth) {
  const salt =
    waterType === "harbor" ||
    waterType === "coastal" ||
    waterType === "rockyCoast";
  if (salt && (windLevel === "high" || lineDepth.startsWith("Near bottom"))) {
    return "none (bottom presentation)";
  }
  if (salt) {
    return "sliding float";
  }
  return "standard bobber";
}

function buildExplanation({
  spotName,
  waterType,
  timeOfDay,
  weather,
  windLevel,
  recommendedFish,
  bait,
  lineDepth,
}) {
  return (
    `For ${spotName} (${labelWaterType(waterType)}), ${timeOfDay} with ${weather} conditions ` +
    `and ${windLevel} wind, try ${recommendedFish} using ${bait}. ` +
    `Start around ${lineDepth.toLowerCase()} and adjust if the bite is slow—` +
    `always follow local regulations and safety advice.`
  );
}

/** Used when inputs are valid but spot lookup fails (should not happen after route validation). */
function fallbackRecommendation(body) {
  const windLevel = body.windLevel ?? "medium";
  const sinkerWeight = pickSinkerWeight(windLevel, "lake");
  const lineDepth = pickLineDepth("lake", windLevel, body.timeOfDay ?? "morning");
  const floatType = pickFloatType("lake", windLevel, lineDepth);
  const fishKey = "perch";

  return {
    selectedSpotName: "General (fallback)",
    waterType: "lake",
    targetFish: formatTargetFish(body.targetFish),
    recommendedFish: FISH_LABELS[fishKey],
    bait: pickBait(fishKey, body.weather ?? "cloudy"),
    lineDepth,
    sinkerWeight,
    floatType,
    explanation:
      "We could not match a specific spot in our catalog, so here is a simple freshwater-style " +
      "starting point. Choose a listed location on the form for advice tailored to that place.",
    usedFallback: true,
  };
}

/**
 * Rule-based recommendation. Expects validated enums: location id, timeOfDay, weather, windLevel;
 * targetFish optional (may be empty string).
 */
export function recommend(body) {
  const { location, timeOfDay, weather, windLevel, targetFish = "" } = body;

  const spot = spotsById.get(location);
  if (!spot) {
    return fallbackRecommendation(body);
  }

  const fishKey = resolveFishKey(spot, targetFish);
  const recommendedFish = FISH_LABELS[fishKey];
  const bait = pickBait(fishKey, weather);
  const lineDepth = pickLineDepth(spot.waterType, windLevel, timeOfDay);
  const sinkerWeight = pickSinkerWeight(windLevel, spot.waterType);
  const floatType = pickFloatType(spot.waterType, windLevel, lineDepth);
  const explanation = buildExplanation({
    spotName: spot.name,
    waterType: spot.waterType,
    timeOfDay,
    weather,
    windLevel,
    recommendedFish,
    bait,
    lineDepth,
  });

  return {
    selectedSpotName: spot.name,
    waterType: spot.waterType,
    targetFish: formatTargetFish(targetFish),
    recommendedFish,
    bait,
    lineDepth,
    sinkerWeight,
    floatType,
    explanation,
    usedFallback: false,
  };
}
