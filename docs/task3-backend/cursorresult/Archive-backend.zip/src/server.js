import express from "express";
import cors from "cors";
import { fishingSpots } from "./spots.js";
import { recommend } from "./recommendEngine.js";

const PORT = Number(process.env.PORT) || 3001;

const app = express();

app.use(
  cors({
    origin: ["http://localhost:5173", "http://127.0.0.1:5173"],
  })
);
app.use(express.json());

const ALLOWED_TIME = new Set(["morning", "afternoon", "evening", "night"]);
const ALLOWED_WEATHER = new Set(["sunny", "cloudy", "rainy", "overcast"]);
const ALLOWED_WIND = new Set(["low", "medium", "high"]);
const ALLOWED_TARGET_FISH = new Set([
  "snapper",
  "kahawai",
  "trevally",
  "trout",
  "perch",
]);
const SPOT_IDS = new Set(fishingSpots.map((s) => s.id));

function collectValidationErrors(body) {
  const errors = [];
  const { location, timeOfDay, weather, windLevel, targetFish } = body ?? {};

  if (!location || typeof location !== "string") {
    errors.push("location");
  } else if (!SPOT_IDS.has(location)) {
    errors.push("location");
  }

  if (!timeOfDay || !ALLOWED_TIME.has(timeOfDay)) {
    errors.push("timeOfDay");
  }
  if (!weather || !ALLOWED_WEATHER.has(weather)) {
    errors.push("weather");
  }
  if (!windLevel || !ALLOWED_WIND.has(windLevel)) {
    errors.push("windLevel");
  }

  if (
    targetFish != null &&
    targetFish !== "" &&
    typeof targetFish === "string" &&
    !ALLOWED_TARGET_FISH.has(targetFish)
  ) {
    errors.push("targetFish");
  }

  return errors;
}

app.get("/api/health", (req, res) => {
  res.json({ ok: true });
});

app.get("/api/spots", (req, res) => {
  res.json(fishingSpots);
});

app.post("/api/recommendation", (req, res) => {
  const errors = collectValidationErrors(req.body);
  if (errors.length > 0) {
    return res.status(400).json({
      error: "Invalid or missing fields. Check values against the form options.",
      fields: errors,
    });
  }

  const { location, timeOfDay, weather, windLevel, targetFish = "" } = req.body;
  const result = recommend({
    location,
    timeOfDay,
    weather,
    windLevel,
    targetFish: typeof targetFish === "string" ? targetFish : "",
  });

  res.json(result);
});

app.listen(PORT, () => {
  console.log(`FishWise API listening on http://localhost:${PORT}`);
});
